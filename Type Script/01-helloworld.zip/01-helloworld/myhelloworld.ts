console.log("Hello World");
console.log("Coding Gurus! " + "Time for some fun!");